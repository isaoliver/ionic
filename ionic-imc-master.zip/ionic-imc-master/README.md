# ionic-imc
App de estudo que calcula o IMC de crianças, jovens e adultos
